const fs = require('fs');
const path = require('path');

// Ensure data directory exists
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize files if they don't exist
const configFile = path.join(dataDir, 'config.json');
const protectedUsersFile = path.join(dataDir, 'protected_users.json');
const powerRolesFile = path.join(dataDir, 'power_roles.json');

if (!fs.existsSync(configFile)) {
    fs.writeFileSync(configFile, '{}');
}

if (!fs.existsSync(protectedUsersFile)) {
    fs.writeFileSync(protectedUsersFile, '{}');
}

if (!fs.existsSync(powerRolesFile)) {
    fs.writeFileSync(powerRolesFile, '{}');
}

// Config functions
function loadConfig() {
    try {
        const data = fs.readFileSync(configFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading config:', error);
        return {};
    }
}

function saveConfig(config) {
    try {
        fs.writeFileSync(configFile, JSON.stringify(config, null, 2));
    } catch (error) {
        console.error('Error saving config:', error);
    }
}

// Protected users functions
function loadProtectedUsers() {
    try {
        const data = fs.readFileSync(protectedUsersFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading protected users:', error);
        return {};
    }
}

function saveProtectedUsers(users) {
    try {
        fs.writeFileSync(protectedUsersFile, JSON.stringify(users, null, 2));
    } catch (error) {
        console.error('Error saving protected users:', error);
    }
}

// Power roles functions
function loadPowerRoles() {
    try {
        const data = fs.readFileSync(powerRolesFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error loading power roles:', error);
        return {};
    }
}

function savePowerRoles(roles) {
    try {
        fs.writeFileSync(powerRolesFile, JSON.stringify(roles, null, 2));
    } catch (error) {
        console.error('Error saving power roles:', error);
    }
}

module.exports = {
    loadConfig,
    saveConfig,
    loadProtectedUsers,
    saveProtectedUsers,
    loadPowerRoles,
    savePowerRoles
};
