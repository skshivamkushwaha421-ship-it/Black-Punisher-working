const { EmbedBuilder } = require('discord.js');

// Create success embed (green)
function createSuccessEmbed(title, description) {
    return new EmbedBuilder()
        .setTitle(`✅ ${title}`)
        .setDescription(description)
        .setColor('#00ff88') // Bright green
        .setTimestamp()
        .setFooter({ text: '🛡️ Protection System' });
}

// Create error embed (red)
function createErrorEmbed(description) {
    return new EmbedBuilder()
        .setTitle('❌ Error')
        .setDescription(description)
        .setColor('#ff4757') // Bright red
        .setTimestamp()
        .setFooter({ text: '🛡️ Protection System' });
}

// Create info embed (blue)
function createInfoEmbed(title, description) {
    return new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor('#3742fa') // Bright blue
        .setTimestamp()
        .setFooter({ text: '🛡️ Protection System' });
}

// Create warning embed (orange/yellow)
function createWarningEmbed(title, description) {
    return new EmbedBuilder()
        .setTitle(`⚠️ ${title}`)
        .setDescription(description)
        .setColor('#ffa502') // Bright orange
        .setTimestamp()
        .setFooter({ text: '🛡️ Protection System' });
}

module.exports = {
    createSuccessEmbed,
    createErrorEmbed,
    createInfoEmbed,
    createWarningEmbed
};
