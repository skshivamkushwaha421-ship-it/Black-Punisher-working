const { loadPowerRoles } = require('./database');

// Apply punishment to a member
async function applyPunishment(member, guild, reason) {
    const punishments = [];
    
    try {
        // Remove power roles
        const powerRoles = loadPowerRoles();
        const guildPowerRoles = powerRoles[guild.id] || [];
        
        for (const roleId of guildPowerRoles) {
            if (member.roles.cache.has(roleId)) {
                try {
                    await member.roles.remove(roleId, `Protection system: ${reason}`);
                    const role = guild.roles.cache.get(roleId);
                    punishments.push(`Removed role: ${role ? role.name : 'Unknown Role'}`);
                } catch (error) {
                    console.error(`Failed to remove role ${roleId}:`, error);
                }
            }
        }
        
        // Apply 60-minute timeout (only if bot has permission)
        try {
            const timeoutDuration = 60 * 60 * 1000; // 60 minutes in milliseconds
            const timeoutUntil = new Date(Date.now() + timeoutDuration);
            
            await member.timeout(timeoutDuration, `Protection system: ${reason}`);
            punishments.push(`Applied 60-minute timeout until ${timeoutUntil.toLocaleString()}`);
        } catch (timeoutError) {
            console.error('Failed to apply timeout (missing permissions):', timeoutError.message);
            punishments.push('Failed to apply timeout - missing permissions');
        }
        
        console.log(`Punishment applied to ${member.user.tag}:`, punishments);
        return punishments;
        
    } catch (error) {
        console.error('Error applying punishment:', error);
        throw error;
    }
}

// Test punishment function (same as regular punishment but with different reason)
async function testPunishment(member, guild, reason) {
    return await applyPunishment(member, guild, `TEST: ${reason}`);
}

module.exports = {
    applyPunishment,
    testPunishment
};
