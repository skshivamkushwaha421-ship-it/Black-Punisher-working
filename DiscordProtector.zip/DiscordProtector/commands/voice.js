const { EmbedBuilder } = require('discord.js');
const { joinVoiceChannel, getVoiceConnection, VoiceConnectionStatus } = require('@discordjs/voice');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../utils/embeds');

// Join voice channel command
async function join_vc(message) {
    const voiceChannel = message.member.voice.channel;
    
    if (!voiceChannel) {
        return message.reply({ embeds: [createErrorEmbed('You need to be in a voice channel for me to join!')] });
    }

    try {
        const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: voiceChannel.guild.id,
            adapterCreator: voiceChannel.guild.voiceAdapterCreator,
        });
        
        const embed = createSuccessEmbed(
            'Voice Channel Joined',
            `🎤 Successfully joined **${voiceChannel.name}**\n👥 **${voiceChannel.members.size}** members in channel`
        );
        
        embed.addFields({ name: 'Channel ID', value: voiceChannel.id, inline: true });
        
        await message.reply({ embeds: [embed] });

        // Store the bot's current voice channel for tracking moves
        message.client.botVoiceChannel = voiceChannel;

    } catch (error) {
        console.error('Error joining voice channel:', error);
        await message.reply({ embeds: [createErrorEmbed('Failed to join voice channel. Check my permissions!')] });
    }
}

module.exports = {
    join_vc
};
