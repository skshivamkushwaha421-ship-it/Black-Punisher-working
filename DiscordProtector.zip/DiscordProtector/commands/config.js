const { EmbedBuilder } = require('discord.js');
const { loadConfig, saveConfig, loadProtectedUsers, loadPowerRoles } = require('../utils/database');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../utils/embeds');

// Add power role command - restricted to specific user
async function add_power_role(message, args) {
    // Only allow specific user to use this command
    if (message.author.id !== '493370849114718218') {
        return message.reply({ embeds: [createErrorEmbed('Only the bot owner can use this command.')] });
    }

    if (!message.member.permissions.has('MANAGE_ROLES')) {
        return message.reply({ embeds: [createErrorEmbed('You need "Manage Roles" permission to use this command.')] });
    }

    if (!args[0]) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a role to add. Usage: `!add_power_role @role`')] });
    }

    const role = message.mentions.roles.first();
    if (!role) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a valid role.')] });
    }

    const powerRoles = loadPowerRoles();
    const guildId = message.guild.id;
    
    if (!powerRoles[guildId]) {
        powerRoles[guildId] = [];
    }

    if (powerRoles[guildId].includes(role.id)) {
        return message.reply({ embeds: [createErrorEmbed(`Role **${role.name}** is already in the power roles list.`)] });
    }

    powerRoles[guildId].push(role.id);
    savePowerRoles(powerRoles);

    const embed = createSuccessEmbed(
        'Power Role Added',
        `⚡ Role **${role.name}** has been added to the power roles list.\nThis role will be removed as punishment.`
    );

    await message.reply({ embeds: [embed] });
}

// Remove power role command - restricted to specific user
async function remove_power_role(message, args) {
    // Only allow specific user to use this command
    if (message.author.id !== '493370849114718218') {
        return message.reply({ embeds: [createErrorEmbed('Only the bot owner can use this command.')] });
    }

    if (!message.member.permissions.has('MANAGE_ROLES')) {
        return message.reply({ embeds: [createErrorEmbed('You need "Manage Roles" permission to use this command.')] });
    }

    if (!args[0]) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a role to remove. Usage: `!remove_power_role @role`')] });
    }

    const role = message.mentions.roles.first();
    if (!role) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a valid role.')] });
    }

    const powerRoles = loadPowerRoles();
    const guildId = message.guild.id;
    
    if (!powerRoles[guildId] || !powerRoles[guildId].includes(role.id)) {
        return message.reply({ embeds: [createErrorEmbed(`Role **${role.name}** is not in the power roles list.`)] });
    }

    powerRoles[guildId] = powerRoles[guildId].filter(id => id !== role.id);
    savePowerRoles(powerRoles);

    const embed = createSuccessEmbed(
        'Power Role Removed',
        `❌ Role **${role.name}** has been removed from the power roles list.`
    );

    await message.reply({ embeds: [embed] });
}

// Set log channel command
async function set_log_channel(message, args) {
    if (!message.member.permissions.has('MANAGE_CHANNELS')) {
        return message.reply({ embeds: [createErrorEmbed('You need "Manage Channels" permission to use this command.')] });
    }

    let targetChannel;
    
    if (args[0]) {
        // Channel mentioned
        targetChannel = message.mentions.channels.first();
        if (!targetChannel) {
            return message.reply({ embeds: [createErrorEmbed('Please mention a valid channel.')] });
        }
    } else {
        // Use current channel
        targetChannel = message.channel;
    }

    const config = loadConfig();
    const guildId = message.guild.id;
    
    if (!config[guildId]) {
        config[guildId] = {};
    }

    config[guildId].logChannel = targetChannel.id;
    saveConfig(config);

    const embed = createSuccessEmbed(
        'Log Channel Set',
        `📝 Log channel has been set to ${targetChannel}\nAll protection events will be logged here.`
    );

    await message.reply({ embeds: [embed] });
}

// Check protection configuration
async function check_protection(message) {
    const config = loadConfig();
    const protectedUsers = loadProtectedUsers();
    const powerRoles = loadPowerRoles();
    const guildId = message.guild.id;

    const embed = createInfoEmbed('🔧 Protection Configuration', 'Current bot configuration for this server:');

    // Protected users
    let protectedList = 'None';
    if (protectedUsers[guildId] && protectedUsers[guildId].length > 0) {
        protectedList = '';
        for (const userId of protectedUsers[guildId].slice(0, 10)) { // Limit to 10 for embed space
            try {
                const user = await message.client.users.fetch(userId);
                protectedList += `• ${user.tag}\n`;
            } catch (error) {
                protectedList += `• Unknown User (${userId})\n`;
            }
        }
        if (protectedUsers[guildId].length > 10) {
            protectedList += `... and ${protectedUsers[guildId].length - 10} more`;
        }
    }

    // Power roles
    let rolesList = 'None';
    if (powerRoles[guildId] && powerRoles[guildId].length > 0) {
        rolesList = '';
        for (const roleId of powerRoles[guildId]) {
            const role = message.guild.roles.cache.get(roleId);
            if (role) {
                rolesList += `• ${role.name}\n`;
            } else {
                rolesList += `• Unknown Role (${roleId})\n`;
            }
        }
    }

    // Log channel
    let logChannel = 'Not set';
    if (config[guildId] && config[guildId].logChannel) {
        const channel = message.guild.channels.cache.get(config[guildId].logChannel);
        logChannel = channel ? `${channel}` : 'Channel not found';
    }

    embed.addFields(
        { name: '🛡️ Protected Users', value: protectedList, inline: false },
        { name: '⚡ Power Roles', value: rolesList, inline: false },
        { name: '📝 Log Channel', value: logChannel, inline: false }
    );

    await message.reply({ embeds: [embed] });
}

// Help command
async function help_protection(message) {
    const embed = createInfoEmbed('🛡️ Protection Bot Help', 'Complete command reference:');

    embed.addFields(
        { 
            name: '👤 User Protection Commands', 
            value: '`!protect_user @user` - Add user to protected list\n`!unprotect_user @user` - Remove user from protected list\n`!list_protected` - Show all protected users', 
            inline: false 
        },
        { 
            name: '⚡ Role Management Commands', 
            value: '`!add_power_role @role` - Add role to punishment list\n`!remove_power_role @role` - Remove role from punishment list', 
            inline: false 
        },
        { 
            name: '🎤 Voice Channel Commands', 
            value: '`!join_vc` - Bot joins your voice channel\n*Auto-move: Bot moves all members when dragged to new channel*', 
            inline: false 
        },
        { 
            name: '📝 Configuration Commands', 
            value: '`!set_log_channel #channel` - Set specific log channel\n`!set_log_channel` - Set current channel as log channel', 
            inline: false 
        },
        { 
            name: '🔧 Utility Commands', 
            value: '`!test_punishment @user` - Test punishment system\n`!check_protection` - View current configuration\n`!help_protection` - Show this help message', 
            inline: false 
        },
        { 
            name: '⚖️ Automatic Punishment', 
            value: 'When someone disconnects, moves, mutes, or deafens a protected user:\n• Their power roles are removed\n• They get 60-minute timeout\n• Action is logged to set channel', 
            inline: false 
        }
    );

    embed.setFooter({ text: '⚡ All responses use embedded messages for visual clarity' });

    await message.reply({ embeds: [embed] });
}

// Helper function to save power roles (missing from database.js)
function savePowerRoles(powerRoles) {
    const fs = require('fs');
    const path = require('path');
    fs.writeFileSync(path.join(__dirname, '..', 'data', 'power_roles.json'), JSON.stringify(powerRoles, null, 2));
}

module.exports = {
    add_power_role,
    remove_power_role,
    set_log_channel,
    check_protection,
    help_protection
};
