const { EmbedBuilder } = require('discord.js');
const { loadProtectedUsers, saveProtectedUsers } = require('../utils/database');
const { createSuccessEmbed, createErrorEmbed, createInfoEmbed } = require('../utils/embeds');
const { testPunishment } = require('../utils/punishment');

// Protect user command - restricted to specific user
async function protect_user(message, args) {
    // Only allow specific user to use this command
    if (message.author.id !== '493370849114718218') {
        return message.reply({ embeds: [createErrorEmbed('Only the bot owner can use this command.')] });
    }

    if (!message.member.permissions.has('MANAGE_ROLES')) {
        return message.reply({ embeds: [createErrorEmbed('You need "Manage Roles" permission to use this command.')] });
    }

    if (!args[0]) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a user to protect. Usage: `!protect_user @user`')] });
    }

    const user = message.mentions.users.first();
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a valid user.')] });
    }

    const protectedUsers = loadProtectedUsers();
    const guildId = message.guild.id;
    
    if (!protectedUsers[guildId]) {
        protectedUsers[guildId] = [];
    }

    if (protectedUsers[guildId].includes(user.id)) {
        return message.reply({ embeds: [createErrorEmbed(`${user.tag} is already protected.`)] });
    }

    protectedUsers[guildId].push(user.id);
    saveProtectedUsers(protectedUsers);

    const embed = createSuccessEmbed(
        'User Protected',
        `🛡️ ${user.tag} has been added to the protected users list.`
    );

    await message.reply({ embeds: [embed] });
}

// Unprotect user command - restricted to specific user
async function unprotect_user(message, args) {
    // Only allow specific user to use this command
    if (message.author.id !== '493370849114718218') {
        return message.reply({ embeds: [createErrorEmbed('Only the bot owner can use this command.')] });
    }

    if (!message.member.permissions.has('MANAGE_ROLES')) {
        return message.reply({ embeds: [createErrorEmbed('You need "Manage Roles" permission to use this command.')] });
    }

    if (!args[0]) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a user to unprotect. Usage: `!unprotect_user @user`')] });
    }

    const user = message.mentions.users.first();
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a valid user.')] });
    }

    const protectedUsers = loadProtectedUsers();
    const guildId = message.guild.id;
    
    if (!protectedUsers[guildId] || !protectedUsers[guildId].includes(user.id)) {
        return message.reply({ embeds: [createErrorEmbed(`${user.tag} is not in the protected users list.`)] });
    }

    protectedUsers[guildId] = protectedUsers[guildId].filter(id => id !== user.id);
    saveProtectedUsers(protectedUsers);

    const embed = createSuccessEmbed(
        'User Unprotected',
        `🚫 ${user.tag} has been removed from the protected users list.`
    );

    await message.reply({ embeds: [embed] });
}

// List protected users command
async function list_protected(message) {
    const protectedUsers = loadProtectedUsers();
    const guildId = message.guild.id;
    
    if (!protectedUsers[guildId] || protectedUsers[guildId].length === 0) {
        return message.reply({ embeds: [createInfoEmbed('No Protected Users', 'There are currently no protected users in this server.')] });
    }

    let userList = '';
    for (const userId of protectedUsers[guildId]) {
        try {
            const user = await message.client.users.fetch(userId);
            userList += `• ${user.tag} (${user.id})\n`;
        } catch (error) {
            userList += `• Unknown User (${userId}) - *User may have left*\n`;
        }
    }

    const embed = createInfoEmbed(
        '🛡️ Protected Users',
        userList || 'No protected users found.'
    );

    await message.reply({ embeds: [embed] });
}

// Test punishment command
async function test_punishment(message, args) {
    if (!message.member.permissions.has('MANAGE_ROLES')) {
        return message.reply({ embeds: [createErrorEmbed('You need "Manage Roles" permission to use this command.')] });
    }

    if (!args[0]) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a user to test punishment on. Usage: `!test_punishment @user`')] });
    }

    const user = message.mentions.users.first();
    if (!user) {
        return message.reply({ embeds: [createErrorEmbed('Please mention a valid user.')] });
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
        return message.reply({ embeds: [createErrorEmbed('User is not in this server.')] });
    }

    try {
        await testPunishment(member, message.guild, 'Manual test by ' + message.author.tag);
        
        const embed = createSuccessEmbed(
            'Test Punishment Applied',
            `🔨 Test punishment has been applied to ${user.tag}.\n\n**Actions taken:**\n• Power roles removed\n• 60-minute timeout applied`
        );

        await message.reply({ embeds: [embed] });
    } catch (error) {
        console.error('Error applying test punishment:', error);
        await message.reply({ embeds: [createErrorEmbed('Failed to apply test punishment. Check bot permissions.')] });
    }
}

module.exports = {
    protect_user,
    unprotect_user,
    list_protected,
    test_punishment
};
