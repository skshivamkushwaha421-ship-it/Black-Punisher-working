# Discord Protection Bot

## Overview

This is a Discord moderation bot designed to protect specific users from voice channel abuse. The bot monitors voice-related actions (disconnects, moves, mutes, deafens) against protected users and automatically punishes offenders by removing their designated roles and applying timeouts. It also includes voice channel management features where the bot can join channels and automatically move members when it's moved between channels.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Discord.js v14**: Primary framework for Discord API interaction
- **Event-driven architecture**: Separate event handlers for different Discord events
- **Command-based system**: Prefix-based commands (using "!" prefix) with modular command loading
- **File-based data storage**: JSON files for persistence without external database dependencies

### Core Components

#### Command System
- **Modular command loading**: Commands organized in separate files within `/commands` directory
- **Permission-based access**: Commands require specific Discord permissions (MANAGE_ROLES)
- **Argument parsing**: Simple space-separated argument handling for command parameters

#### Protection System
- **User protection list**: Maintains per-guild lists of protected users
- **Power role management**: Configurable roles that get removed as punishment
- **Audit log monitoring**: Real-time monitoring of Discord audit logs for voice-related actions
- **Automatic punishment**: 60-minute timeout + role removal for offenders

#### Voice Channel Management
- **Bot movement tracking**: Automatically moves members when bot is dragged between channels
- **Voice state monitoring**: Tracks voice channel changes for both bot and users
- **Channel reporting**: Embedded messages showing movement statistics and channel information

#### Data Persistence
- **JSON-based storage**: Three separate JSON files for different data types
  - `config.json`: General bot configuration per guild
  - `protected_users.json`: Lists of protected users per guild
  - `power_roles.json`: Punishment roles per guild
- **File system utilities**: Automatic directory creation and file initialization
- **Error handling**: Graceful degradation when files are corrupted or missing

#### Event Handling
- **Voice state updates**: Monitors voice channel changes for automated member movement
- **Audit log entries**: Real-time punishment system based on moderation actions
- **Message events**: Command processing and response handling

#### Response System
- **Embedded messages**: Rich embeds for all bot responses with color coding
- **Visual feedback**: Different colors for success (green), error (red), info (blue), and warning (orange)
- **Consistent branding**: Footer branding and timestamps on all embeds

### Design Patterns

#### Modular Architecture
- **Separation of concerns**: Commands, events, utilities, and data handling in separate modules
- **Dynamic loading**: Runtime discovery and loading of command and event files
- **Reusable utilities**: Shared functions for database operations, embeds, and punishment logic

#### Guild-based Configuration
- **Multi-server support**: All configurations stored per Discord guild ID
- **Isolated data**: Each server maintains independent protection lists and role configurations
- **Scalable storage**: JSON structure allows easy addition of new guilds

#### Permission-based Security
- **Role verification**: Commands require appropriate Discord permissions
- **Action validation**: Checks user permissions before executing sensitive operations
- **Audit trail**: All actions logged with timestamps and responsible users

## External Dependencies

### Discord Integration
- **Discord.js Library**: Official Discord API wrapper for Node.js
- **Gateway Intents**: Requires specific intents for guilds, messages, voice states, and moderation
- **Partials**: Handles partial data for channels, messages, users, and guild members

### Discord API Features
- **Audit Logs**: Real-time monitoring of moderation actions
- **Voice Connections**: Bot can join and manage voice channels
- **Role Management**: Automated role removal and permission handling
- **Timeout System**: 60-minute member timeouts for punishment
- **Embed Messages**: Rich message formatting for user interactions

### File System
- **Node.js fs module**: File operations for JSON data persistence
- **Path module**: Cross-platform file path handling
- **Directory management**: Automatic creation of data directories

### Runtime Requirements
- **Node.js**: Runtime environment for JavaScript execution
- **Discord Bot Token**: Required for authentication with Discord API
- **Server Permissions**: Bot requires specific permissions for moderation actions