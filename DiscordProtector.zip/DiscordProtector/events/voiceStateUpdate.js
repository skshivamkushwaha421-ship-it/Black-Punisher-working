const { EmbedBuilder } = require('discord.js');
const { createInfoEmbed } = require('../utils/embeds');
const { loadProtectedUsers } = require('../utils/database');
const { applyPunishment } = require('../utils/punishment');

// Store recent voice movements to correlate with audit logs
const recentVoiceChanges = new Map();

module.exports = {
    name: 'voiceStateUpdate',
    execute: async (oldState, newState, client) => {
        // Handle bot being moved between voice channels
        if (newState.id === client.user.id && oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id) {
            await handleBotMove(oldState, newState, client);
            return;
        }

        // Track voice state changes for protected users
        const protectedUsers = loadProtectedUsers();
        const guildProtected = protectedUsers[newState.guild.id] || [];
        
        if (guildProtected.includes(newState.id)) {
            const wasDisconnected = !newState.channel && oldState.channel;
            const wasMoved = oldState.channel && newState.channel && oldState.channel.id !== newState.channel.id;
            
            console.log('🛡️ PROTECTED USER VOICE CHANGE:', {
                user: newState.member.user.tag,
                userId: newState.id,
                oldChannel: oldState.channel?.name,
                newChannel: newState.channel?.name,
                wasDisconnected,
                wasMoved
            });

            // If this is a disconnect, let's wait a moment and check for punishments manually
            if (wasDisconnected) {
                console.log('🚨 PROTECTED USER DISCONNECTED! Checking for recent audit log entries...');
                setTimeout(async () => {
                    try {
                        const auditLogs = await newState.guild.fetchAuditLogs({
                            type: 27, // MemberDisconnect
                            limit: 5
                        });
                        
                        console.log('📋 Recent disconnect audit logs:', auditLogs.entries.map(entry => ({
                            id: entry.id,
                            executor: entry.executor?.tag,
                            target: entry.target?.tag,
                            targetId: entry.targetId,
                            createdAt: entry.createdAt,
                            action: entry.action
                        })));
                        
                        // Check if any recent disconnect was targeting our protected user
                        const recentDisconnect = auditLogs.entries.find(entry => {
                            const timeDiff = Date.now() - entry.createdTimestamp;
                            return timeDiff < 5000 && entry.targetId === newState.id;
                        });
                        
                        if (recentDisconnect) {
                            console.log('💥 FOUND MATCHING DISCONNECT AUDIT LOG! Applying punishment...');
                            const { applyPunishment } = require('../utils/punishment');
                            await applyPunishment(newState.guild, recentDisconnect.executor, newState.member.user, 'disconnect');
                        } else {
                            console.log('❌ No matching audit log found for this disconnect');
                        }
                    } catch (error) {
                        console.log('❌ Error checking audit logs:', error.message);
                    }
                }, 1000); // Wait 1 second for audit log to appear
            }

            // Store this change with timestamp for correlation with audit logs
            recentVoiceChanges.set(newState.id, {
                user: newState.member.user,
                timestamp: Date.now(),
                action: !newState.channel ? 'disconnect' : (oldState.channel && newState.channel ? 'move' : 'join'),
                oldChannel: oldState.channel,
                newChannel: newState.channel
            });

            // Clean up old entries (older than 5 seconds)
            setTimeout(() => {
                recentVoiceChanges.delete(newState.id);
            }, 5000);
        }
    }
};

// Export the recent changes map so audit log handler can access it
module.exports.getRecentVoiceChanges = () => recentVoiceChanges;

async function handleBotMove(oldState, newState, client) {
    const oldChannel = oldState.channel;
    const newChannel = newState.channel;
    
    if (!oldChannel || !newChannel) return;

    // Get all members from the old channel (excluding the bot)
    const membersToMove = oldChannel.members.filter(member => member.id !== client.user.id);
    let movedCount = 0;

    // Move each member to the new channel
    for (const [memberId, member] of membersToMove) {
        try {
            await member.voice.setChannel(newChannel);
            movedCount++;
        } catch (error) {
            console.error(`Failed to move member ${member.user.tag}:`, error);
        }
    }

    // Find the command channel to send response (use system channel or first text channel as fallback)
    const guild = newChannel.guild;
    let responseChannel = guild.systemChannel;
    
    if (!responseChannel) {
        responseChannel = guild.channels.cache.find(channel => 
            channel.type === 0 && // TEXT channel
            channel.permissionsFor(guild.members.me).has(['SendMessages', 'EmbedLinks'])
        );
    }

    if (responseChannel) {
        const embed = createInfoEmbed(
            '🎤 Voice Channel Movement',
            `Bot was moved and brought members along!`
        );

        embed.addFields(
            { name: '📤 From Channel', value: oldChannel.name, inline: true },
            { name: '📥 To Channel', value: newChannel.name, inline: true },
            { name: '👥 Members Moved', value: `${movedCount}/${membersToMove.size}`, inline: true }
        );

        embed.setTimestamp();

        try {
            await responseChannel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Failed to send voice movement notification:', error);
        }
    }
}
