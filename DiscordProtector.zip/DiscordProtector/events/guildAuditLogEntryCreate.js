const { AuditLogEvent } = require('discord.js');
const { loadProtectedUsers, loadConfig } = require('../utils/database');
const { applyPunishment } = require('../utils/punishment');
const { createWarningEmbed } = require('../utils/embeds');
const voiceStateHandler = require('./voiceStateUpdate');

module.exports = {
    name: 'guildAuditLogEntryCreate',
    execute: async (auditLogEntry, guild, client) => {
        console.log('🚨 AUDIT LOG EVENT TRIGGERED! This means the bot has audit log access.');
        console.log('📊 Event details:');
        console.log('   - Event received at:', new Date().toISOString());
        console.log('   - Guild:', guild.name);
        console.log('   - Bot permissions include ViewAuditLog:', guild.members.me.permissions.has('ViewAuditLog'));
        console.log('🔍 AUDIT EVENT:', {
            action: auditLogEntry.action,
            executor: auditLogEntry.executor?.tag,
            target: auditLogEntry.target?.tag,
            targetId: auditLogEntry.targetId,
            targetType: auditLogEntry.targetType,
            extra: auditLogEntry.extra,
            changes: auditLogEntry.changes,
            guildId: guild.id
        });
        
        console.log('🔍 RAW AUDIT LOG ENTRY:', auditLogEntry);

        // Get protected users for this guild
        const protectedUsers = loadProtectedUsers();
        const guildProtected = protectedUsers[guild.id] || [];
        
        console.log('🛡️ Protected users:', guildProtected);
        
        if (guildProtected.length === 0) {
            console.log('❌ No protected users configured');
            return; // No protected users to monitor
        }

        const { action, executor, target, reason, extra } = auditLogEntry;
        
        // Skip if executor is the bot itself or system
        if (!executor || executor.bot || executor.system) {
            return;
        }

        // Try to get target from different sources
        let actualTarget = target;
        let targetId = target?.id || auditLogEntry.targetId;
        let actionDescription = '';
        let shouldPunish = false;
        
        console.log('🎯 Initial target extraction:', {
            'target?.id': target?.id,
            'auditLogEntry.targetId': auditLogEntry.targetId,
            'finalTargetId': targetId
        });
        
        // For voice actions without target, check recent voice state changes
        if (!targetId && (action === 26 || action === 27)) {
            console.log('🔍 No target in audit log, checking recent voice changes...');
            const recentChanges = voiceStateHandler.getRecentVoiceChanges();
            console.log('📡 Recent voice changes:', Array.from(recentChanges.entries()));
            
            // Find recent voice change that matches this timeframe (within last 3 seconds)
            const now = Date.now();
            for (const [userId, changeData] of recentChanges) {
                if (now - changeData.timestamp < 3000) { // Within 3 seconds
                    console.log('🎯 Found recent voice change for protected user:', {
                        userId,
                        user: changeData.user.tag,
                        action: changeData.action,
                        timeDiff: now - changeData.timestamp
                    });
                    
                    // Use this as our target
                    targetId = userId;
                    actualTarget = changeData.user;
                    actionDescription = action === 26 ? 
                        `moved ${changeData.user.tag} between voice channels` :
                        `disconnected ${changeData.user.tag} from voice channel`;
                    break;
                }
            }
        }
        
        // If target is undefined but targetId exists in the entry, try to get it
        if (!actualTarget && targetId) {
            try {
                actualTarget = await guild.members.fetch(targetId);
                actualTarget = actualTarget.user;
                console.log('📍 Found target via targetId:', actualTarget.tag);
            } catch (error) {
                console.log('❌ Could not fetch target user:', targetId);
            }
        }

        console.log('🎯 Checking action', action, 'with targetId:', targetId);
        console.log('📋 Action types - Disconnect:', AuditLogEvent.MemberDisconnect, 'Move:', AuditLogEvent.MemberMove, 'Update:', AuditLogEvent.MemberUpdate);

        // Check for voice-related actions against protected users
        switch (action) {
            case AuditLogEvent.MemberDisconnect:
            case 27: // Alternative disconnect action
                console.log('📤 DISCONNECT detected');
                if (targetId && guildProtected.includes(targetId)) {
                    console.log('✅ PROTECTED USER DISCONNECTED - WILL PUNISH!');
                    actionDescription = `disconnected ${actualTarget?.tag || 'protected user'} from voice channel`;
                    shouldPunish = true;
                } else {
                    console.log('❌ Not protected or no targetId');
                }
                break;

            case AuditLogEvent.MemberMove:
            case 25: // Action 25 seems to be member move
            case 26: // Alternative move action
                console.log('🔄 MOVE detected');
                if (targetId && guildProtected.includes(targetId)) {
                    console.log('✅ PROTECTED USER MOVED - WILL PUNISH!');
                    actionDescription = `moved ${actualTarget?.tag || 'protected user'} between voice channels`;
                    shouldPunish = true;
                } else {
                    console.log('❌ Not protected or no targetId');
                }
                break;

            case AuditLogEvent.MemberUpdate:
            case 24: // Member update action
                console.log('🔧 UPDATE detected');
                console.log('🔍 Checking changes:', auditLogEntry.changes);
                
                if (targetId && guildProtected.includes(targetId)) {
                    // Check changes directly from auditLogEntry, not extra
                    const changes = auditLogEntry.changes || [];
                    console.log('📋 Available changes:', changes);
                    
                    for (const change of changes) {
                        console.log('🔍 Processing change:', change);
                        
                        if (change.key === 'mute') {
                            console.log('🔇 MUTE change detected:', change);
                            if (change.new === true) {
                                console.log('✅ PROTECTED USER MUTED - WILL PUNISH!');
                                actionDescription = `server-muted ${actualTarget?.tag || 'protected user'}`;
                                shouldPunish = true;
                            } else {
                                console.log('ℹ️ User was unmuted (no punishment)');
                            }
                            break;
                        } else if (change.key === 'deaf') {
                            console.log('🔇 DEAFEN change detected:', change);
                            if (change.new === true) {
                                console.log('✅ PROTECTED USER DEAFENED - WILL PUNISH!');
                                actionDescription = `server-deafened ${actualTarget?.tag || 'protected user'}`;
                                shouldPunish = true;
                            } else {
                                console.log('ℹ️ User was undeafened (no punishment)');
                            }
                            break;
                        }
                    }
                    
                    if (!shouldPunish) {
                        console.log('❌ Update not related to harmful mute/deafen actions');
                    }
                } else {
                    console.log('❌ Not protected, no targetId, or user not in protected list');
                }
                break;
            default:
                console.log('❓ Unknown action:', action);
        }
        
        console.log('🔨 WILL PUNISH?', shouldPunish);

        if (shouldPunish) {
            try {
                // Get the executor as a guild member
                const executorMember = await guild.members.fetch(executor.id);
                
                // Apply punishment
                await applyPunishment(executorMember, guild, actionDescription);
                
                // Log the incident
                await logIncident(guild, executor, actualTarget || { tag: 'Protected User', id: targetId }, actionDescription, client);
                
            } catch (error) {
                console.error('Error applying punishment:', error);
            }
        }
    }
};

async function logIncident(guild, executor, target, actionDescription, client) {
    const config = loadConfig();
    const guildConfig = config[guild.id];
    
    if (!guildConfig || !guildConfig.logChannel) return;

    const logChannel = guild.channels.cache.get(guildConfig.logChannel);
    if (!logChannel) return;

    const embed = createWarningEmbed(
        '⚖️ Protection System Activated',
        `A protected user has been targeted!`
    );

    embed.addFields(
        { name: '🎯 Target (Protected User)', value: `${target.tag} (${target.id})`, inline: true },
        { name: '⚔️ Offender', value: `${executor.tag} (${executor.id})`, inline: true },
        { name: '📝 Action Taken', value: actionDescription, inline: false },
        { name: '🔨 Punishment Applied', value: '• Power roles removed\n• 60-minute timeout applied', inline: false },
        { name: '📅 Timestamp', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
    );

    embed.setColor('#ff6b6b'); // Red color for warnings
    embed.setTimestamp();

    try {
        await logChannel.send({ embeds: [embed] });
    } catch (error) {
        console.error('Failed to send log message:', error);
    }
}
