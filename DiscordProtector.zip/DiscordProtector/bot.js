const { Client, GatewayIntentBits, Partials, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { loadConfig, saveConfig } = require('./utils/database');

// Create Discord client with required intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember]
});

// Load commands
client.commands = new Map();
const commandFolders = ['commands'];

for (const folder of commandFolders) {
    const commandFiles = fs.readdirSync(path.join(__dirname, folder)).filter(file => file.endsWith('.js'));
    
    for (const file of commandFiles) {
        const command = require(path.join(__dirname, folder, file));
        for (const [name, handler] of Object.entries(command)) {
            client.commands.set(name, handler);
        }
    }
}

// Load events
const eventFiles = fs.readdirSync(path.join(__dirname, 'events')).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
    const event = require(path.join(__dirname, 'events', file));
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
    } else {
        client.on(event.name, (...args) => event.execute(...args, client));
    }
}

// Command handler
client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith('!')) return;

    const args = message.content.slice(1).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);
    if (!command) return;

    try {
        await command(message, args, client);
    } catch (error) {
        console.error(`Error executing command ${commandName}:`, error);
        const { createErrorEmbed } = require('./utils/embeds');
        await message.reply({ embeds: [createErrorEmbed('An error occurred while executing this command.')] });
    }
});

// Ready event
client.once(Events.ClientReady, (readyClient) => {
    console.log(`✅ Bot is ready! Logged in as ${readyClient.user.tag}`);
    
    // Set bot activity
    client.user.setActivity('Protecting VIP users', { type: 'WATCHING' });
    
    // Check if we're listening for audit log events
    console.log('🔍 Event listeners registered:', client.eventNames());
    
    // Check permissions in first guild
    setTimeout(() => {
        const guild = client.guilds.cache.first();
        if (guild) {
            const permissions = guild.members.me.permissions;
            console.log('🔑 Bot permissions in guild:', {
                'VIEW_AUDIT_LOG': permissions.has('ViewAuditLog'),
                'MANAGE_ROLES': permissions.has('ManageRoles'),
                'MODERATE_MEMBERS': permissions.has('ModerateMembers'),
                'administrator': permissions.has('Administrator')
            });
        }
    }, 2000);
});

// Error handling
client.on('error', console.error);
client.on('warn', console.warn);

process.on('unhandledRejection', error => {
    console.error('Unhandled promise rejection:', error);
});

// Login to Discord
const token = process.env.DISCORD_TOKEN || 'your_discord_token_here';
client.login(token).catch(error => {
    console.error('Failed to login:', error);
    process.exit(1);
});

module.exports = client;
